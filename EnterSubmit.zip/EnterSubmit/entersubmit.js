define( function() {
    "use strict";
    
    function AdvancedControl()
    {       
    };
    AdvancedControl.prototype.initialize = function( oControlHost, fnDoneInitializing )
    {
        function enterSubmit (e) 
       {
            if(e.keyCode === 13) 
            {
                try {oControlHost.finish();} catch {}
                               
            }    
        };

        function setTab () {
            let nL = [...document.querySelectorAll("[specname=textItem]")]
            //console.log(nL)
            nL.forEach((node) =>{
                node.setAttribute('tabindex','-1')
            })
        };
        setTab();
        let exec_submit = document.addEventListener("keydown", enterSubmit, false);
        try {exec_submit;} catch {}

	    fnDoneInitializing();
    };
        
    return AdvancedControl;
});